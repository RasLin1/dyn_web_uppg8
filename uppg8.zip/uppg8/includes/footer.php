<div id="footer">
    <p class="footer-text">Footer</p>
</div>
</div>
</body>
</html>